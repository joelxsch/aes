-- made by @BRLeaks_ --

1. start the AES.exe file.
2. if windows shows a virus alert, start the program anyway.
3. after ignoring the virus alert, the program will start and show everything up to date.